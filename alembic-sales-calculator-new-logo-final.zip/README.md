# Alembic Sales Calculator Android App

Android Studio project wrapping the approved Sales Calculator V5 in a native WebView shell.

## Features
- Same V5 calculator UI/data/logic
- Supabase global Visitors Today counter
- Download Excel via Android bridge
- Direct Share via Android share sheet
- Random quote on each refresh
- Portrait mobile layout

## Build
Open this folder in Android Studio and let Gradle sync. Then use:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

No secret Supabase key is included; the app uses the existing publishable key from the V5 web app.
