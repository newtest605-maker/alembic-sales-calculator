# Alembic Sales Calculator — updated app icon

The launcher icon uses the approved premium black Alembic Sales Calculator artwork. No calculator/web functionality was changed.
